<?php

namespace App\Http\Controllers\Professor;

use App\Http\Controllers\Controller;
use App\Models\Session;
use Illuminate\Http\Request;

class SessionController extends Controller
{
    public function index()
    {
        $sessions = Session::where('professor_id', auth()->user()->professor->id)
            ->orderBy('date', 'desc')
            ->paginate(10);
        return view('professor.sessions.index', compact('sessions'));
    }

    public function create()
    {
        $groups = auth()->user()->professor->groups;
        return view('professor.sessions.create', compact('groups'));
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'date' => 'required|date',
            'start_time' => 'required',
            'end_time' => 'required|after:start_time',
            'group_id' => 'required|exists:groups,id',
            'subject' => 'required|string',
            'content' => 'required|string',
            'homework' => 'nullable|string',
        ]);

        $validated['professor_id'] = auth()->user()->professor->id;

        Session::create($validated);

        return redirect()->route('professor.sessions.index')
            ->with('success', 'Séance créée avec succès.');
    }

    public function edit(Session $session)
    {
        $this->authorize('update', $session);
        $groups = auth()->user()->professor->groups;
        return view('professor.sessions.edit', compact('session', 'groups'));
    }

    public function update(Request $request, Session $session)
    {
        $this->authorize('update', $session);

        $validated = $request->validate([
            'date' => 'required|date',
            'start_time' => 'required',
            'end_time' => 'required|after:start_time',
            'group_id' => 'required|exists:groups,id',
            'subject' => 'required|string',
            'content' => 'required|string',
            'homework' => 'nullable|string',
        ]);

        $session->update($validated);

        return redirect()->route('professor.sessions.index')
            ->with('success', 'Séance mise à jour avec succès.');
    }
}