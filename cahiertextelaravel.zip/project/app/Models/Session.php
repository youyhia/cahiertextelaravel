<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Session extends Model
{
    protected $fillable = [
        'date',
        'start_time',
        'end_time',
        'professor_id',
        'group_id',
        'subject',
        'content',
        'homework',
    ];

    protected $casts = [
        'date' => 'date',
    ];

    public function professor()
    {
        return $this->belongsTo(Professor::class);
    }

    public function group()
    {
        return $this->belongsTo(Group::class);
    }
}