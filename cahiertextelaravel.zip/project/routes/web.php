<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Admin\DepartmentController;
use App\Http\Controllers\Admin\GroupController;
use App\Http\Controllers\Admin\ProfessorController;
use App\Http\Controllers\Professor\SessionController;

Route::get('/', function () {
    return view('welcome');
});

// Routes pour l'authentification
Auth::routes(['register' => false]); // Désactive l'inscription publique

// Routes pour l'admin
Route::middleware(['auth', 'admin'])->prefix('admin')->name('admin.')->group(function () {
    Route::get('/dashboard', [App\Http\Controllers\Admin\DashboardController::class, 'index'])->name('dashboard');
    Route::resource('departments', DepartmentController::class);
    Route::resource('groups', GroupController::class);
    Route::resource('professors', ProfessorController::class);
});

// Routes pour les professeurs
Route::middleware(['auth', 'professor'])->prefix('professor')->name('professor.')->group(function () {
    Route::get('/dashboard', [App\Http\Controllers\Professor\DashboardController::class, 'index'])->name('dashboard');
    Route::resource('sessions', SessionController::class);
});